import { expect, test } from "@playwright/test";

import { resetData, signIn } from "./helpers";

test("sample failure: expects an agenda step that is not current", async ({ page, request }) => {
  await resetData(request);
  await signIn(page, "Blake Brooks");
  await page.goto("/teams/team_lead/meeting");
  await page.getByRole("button", { name: "Start meeting" }).click();
  await expect(
    page.getByRole("list", { name: "Agenda" }).locator('[aria-current="step"]'),
  ).toContainText("Conclude", { timeout: 1500 });
});
