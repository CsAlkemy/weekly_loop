import {
  expect,
  type APIRequestContext,
  type Browser,
  type BrowserContext,
  type Page,
} from "@playwright/test";

const openContexts: BrowserContext[] = [];

export async function resetData(request: APIRequestContext) {
  const response = await request.post("/api/testing/reset");
  expect(response.status(), "API must run with ENABLE_TEST_ROUTES=true").toBe(204);
}

export async function signIn(page: Page, name: string, team = "Leadership") {
  await page.goto("/");
  await page.getByRole("button", { name: new RegExp(name) }).click();
  await expect(page.getByRole("heading", { name: team })).toBeVisible();
}

export async function signedInBrowser(browser: Browser, name: string): Promise<Page> {
  const context = await browser.newContext();
  openContexts.push(context);
  const page = await context.newPage();
  await signIn(page, name);
  return page;
}

export async function closeBrowsers() {
  await Promise.all(openContexts.splice(0).map((context) => context.close()));
}
